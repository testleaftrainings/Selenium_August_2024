package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class TC_002_CreateLeadTC extends ProjectSpecificMethod{

	@Test(dataProvider = "fetchData")
	public void runCreateLead(String cname, String fname, String lname, String phno) throws IOException {
		new LoginPage()
		.enterUsername()
		.enterPassword()
		.clickLoginButton()
		.clickCrmsfaLink()
		.clickLeadsTab()
		.clickCreateLeadLink()
		.enterFirstName(fname)
		.enterCompanyName(cname)
		.enterLastName(lname)
		.enterPhoneNumber(phno)
		.clickCreateLeadButton()
		.verifyLeadId();
	}
	
	@BeforeTest
	public void setTestDetails() {
		testcaseName ="CreateLead";
		testcaseDesc ="CreateLead testcase with valid testData";
		author ="Gokul";
		category = "Regression";
		excelFilename ="CreateLead";
	}
	
	
	
}
