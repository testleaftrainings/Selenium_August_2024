package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class TC_001_LoginTC extends ProjectSpecificMethod{

	@Test
	public void runLogin() throws IOException {
		new LoginPage()
		.enterUsername()
		.enterPassword()
		.clickLoginButton();
	}
	
	@BeforeTest
	public void setTestDetails() {
		testcaseName ="Login";
		testcaseDesc ="Login testcase with valid testData";
		author ="Gokul";
		category = "Regression";
	}
	
	
	
}
