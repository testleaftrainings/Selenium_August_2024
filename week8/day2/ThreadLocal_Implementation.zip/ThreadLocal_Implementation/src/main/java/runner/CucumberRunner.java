package runner;

import org.testng.annotations.BeforeTest;

import base.ProjectSpecificMethod;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features = "src/main/java/features/CreateLead.feature",
				 glue = {"base","pages"},
				 monochrome = true,
				 publish = true)
public class CucumberRunner extends ProjectSpecificMethod {

	@BeforeTest
	public void setTestDetails() {
		testcaseName ="CreateLead";
		testcaseDesc ="CreateLead testcase with valid testData";
		author ="Gokul";
		category = "Regression";
	}
	
}
