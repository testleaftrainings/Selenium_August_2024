package base;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.DataLibrary;

public class ProjectSpecificMethod extends AbstractTestNGCucumberTests{

//	public static RemoteWebDriver driver
	
	//private to secure the variable
	//static for single memory reference
	//final to restrict value changes
	
	private final static ThreadLocal<RemoteWebDriver> rd = new ThreadLocal<RemoteWebDriver>();
	public static Properties prop;
	public static ExtentReports extent;
//	public  ExtentTest childNode;
	public  String testcaseName, testcaseDesc, author, category, excelFilename;
	
	
	private static final ThreadLocal<ExtentTest> test = new ThreadLocal<ExtentTest>();
	private static final ThreadLocal<ExtentTest> node = new ThreadLocal<ExtentTest>();
	private static final ThreadLocal<String> testName = new ThreadLocal<String>();
	
	
	
	
	
	public void setDriver() {
		ChromeDriver driver = new ChromeDriver();
		rd.set(driver);
	}
	
	public RemoteWebDriver getDriver() {
		return rd.get();
	}
	
	@Parameters("propertyFileName")
	@BeforeMethod
	public void preCondition(String propFileName) throws IOException {
		setNode();
		//Step 1: Instance the FileInputStream
		FileInputStream fis = new FileInputStream("./src/main/resources/"+propFileName+".properties");
		
		//Step 2: Create object for Properties
		prop = new Properties();
		
		//Step 3: Load the property file
		prop.load(fis);
				
//		driver = new ChromeDriver();
		setDriver();
		getDriver().get("http://leaftaps.com/opentaps/");
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		getDriver().manage().window().maximize();
	}
	
	@AfterMethod
	public void postCondition() {
		getDriver().close();
	}
	
	
	/*****Report*******/
	
	@BeforeSuite
	public void startReport() {
		// Set the report path
				ExtentHtmlReporter report = new ExtentHtmlReporter("./reports/result.html");
				
				//To maintain history of the report
				report.setAppendExisting(true);
				
				//Create an object for ExtentReports class
				extent = new ExtentReports();
				
				//Attach the report path to configure/create/generate report
				extent.attachReporter(report);
	}
	
	@BeforeClass
	public void createReport() {
		ExtentTest test = extent.createTest(testcaseName, testcaseDesc);
		setTest(test);
		setTestname(testcaseName);
		 
//		node1 = test.createNode(testcaseName);
		
		getTest().assignAuthor(author);
		getTest().assignCategory(category);
		
	}
	
	
	public void setTest(ExtentTest childTest) {
		
		test.set(childTest);;
	}
	
	public ExtentTest getTest() {
		return test.get();
	}
	
	public void setNode() {
		ExtentTest childNode = getTest().createNode(getTestname());
		node.set(childNode);
	}
	
	public ExtentTest getNode() {
		return node.get();
	}
	
	public void setTestname(String name) {
		testName.set(name);
	}
	
	public String getTestname() {
		return testName.get(); 	
	}
	
	@AfterSuite
	public void endReport() {
		extent.flush();
	}
	
	
	@DataProvider(name="fetchData", indices = {0,1})
	public String[][] sendData() throws IOException {
		
		String[][] excelData = DataLibrary.readExcelData(excelFilename);
		
		return excelData;
		
	}
	
	//takeSnap
	
	public int takeSnap() throws IOException {
		int randomNumber = (int) (Math.random()*100000000);
		File src = getDriver().getScreenshotAs(OutputType.FILE);
		File desc = new File("./snaps/img"+randomNumber+".png");
		FileUtils.copyFile(src, desc);
		return randomNumber;
	}
	
	//reportStep
	public void reportStep(String status, String desc) throws IOException {
		if(status.equalsIgnoreCase("pass")) {
			getNode().pass(desc,MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/img"+takeSnap()+".png").build());
		}else if(status.equalsIgnoreCase("fail")) {
			getNode().fail(desc,MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/img"+takeSnap()+".png").build());
		}
	}
	
}
