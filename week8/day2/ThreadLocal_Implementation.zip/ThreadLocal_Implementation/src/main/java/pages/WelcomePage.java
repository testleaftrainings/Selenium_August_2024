package pages;

import java.io.IOException;

import org.openqa.selenium.By;

import base.ProjectSpecificMethod;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class WelcomePage extends ProjectSpecificMethod {

	
	
	@Then ("Verify the login is successfull")
	public void verifyLogin() throws IOException {
		try {
			System.out.println(getDriver().getTitle());
			reportStep("pass", "Login is verified");
		} catch (Exception e) {
			reportStep("fail", "failed to verify login "+e);
		}
	}
	
	@When ("Click on the crmsfa link")
	public HomePage clickCrmsfaLink() throws IOException {
		try {
			getDriver().findElement(By.linkText("CRM/SFA")).click();
			reportStep("pass", "CRM/SFA link clicked successfully");
		} catch (Exception e) {
			reportStep("fail", "Unable to click CRM/SFA link");
		}
		return new HomePage();
	}
	
	public LoginPage clickLogoutButton() {
		
		return new LoginPage();
	}
	
}
