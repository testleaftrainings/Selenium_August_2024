package pages;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.aventstack.extentreports.MediaEntityBuilder;

import base.ProjectSpecificMethod;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class LoginPage extends ProjectSpecificMethod {

	
	

	@Given ("Enter the username")
	public LoginPage enterUsername() throws IOException {
		
		System.out.println("Enter username "+ getDriver());
		
		try {
			getDriver().findElement(By.id("username")).sendKeys(prop.getProperty("username"));
//			File src = getDriver().getScreenshotAs(OutputType.FILE);
//			File desc = new File("./snaps/img1.png");
//			FileUtils.copyFile(src, desc);
//			getNode().pass("username entered successfull",MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/img1.png").build());
			reportStep("pass", "username entered successfull");
		} catch (Exception e) {
//			getNode().fail("unable to enter the username "+e);
			reportStep("fail", "unable to enter the username "+e);
		}
//		LoginPage lp = new LoginPage();
//		return lp;
		
//		return new LoginPage();
		
		return this;
	}
	
	@Given ("Enter the password")
	public LoginPage enterPassword() throws IOException {
		try {
			getDriver().findElement(By.id("password")).sendKeys(prop.getProperty("password"));
//			File src = getDriver().getScreenshotAs(OutputType.FILE);
//			File desc = new File("./snaps/img2.png");
//			FileUtils.copyFile(src, desc);
//			getNode().pass("password entered successfully",MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/img2.png").build());
			reportStep("pass", "password entered successfully");
		} catch (Exception e) {
			reportStep("fail", "unable to enter the password "+e);
		}
		return this;
	}
	
	@When ("Click on the login button")
	public WelcomePage clickLoginButton() throws IOException {
		
		try {
			getDriver().findElement(By.className("decorativeSubmit")).click();
//			File src = getDriver().getScreenshotAs(OutputType.FILE);
//			File desc = new File("./snaps/img3.png");
//			FileUtils.copyFile(src, desc);
//			getNode().pass("Login button clicked successfully",MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/img3.png").build());
			reportStep("pass", "Login button clicked successfully");
		} catch (Exception e) {
			reportStep("fail", "unable to click the Login button "+e);
		}
		return new WelcomePage();
	}
	
	
}
