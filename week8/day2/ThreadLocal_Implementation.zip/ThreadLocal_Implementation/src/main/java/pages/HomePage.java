package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.ProjectSpecificMethod;
import io.cucumber.java.en.When;

public class HomePage extends ProjectSpecificMethod {

	
	

	@When ("Click on leads tab")
	public LeadsPage clickLeadsTab() throws IOException {
		try {
			getDriver().findElement(By.linkText(prop.getProperty("LeadsTab"))).click();
			reportStep("pass", "Leads tab clicked successfully");;
		} catch (Exception e) {
			reportStep("fail", "unable to click leads tab "+e);;
		}
		return new LeadsPage();
	}
	
}
