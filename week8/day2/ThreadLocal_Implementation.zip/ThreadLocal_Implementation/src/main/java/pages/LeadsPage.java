package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.ProjectSpecificMethod;
import io.cucumber.java.en.When;

public class LeadsPage extends ProjectSpecificMethod {

	
	

	@When ("Click on the create lead link")
	public CreateLeadPage clickCreateLeadLink() {
		getDriver().findElement(By.linkText(prop.getProperty("CreateLeadLink"))).click();
		return new CreateLeadPage();
	}
	
	
}
