package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.ProjectSpecificMethod;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class CreateLeadPage extends ProjectSpecificMethod {

	
	
	@Given ("Enter the company name as (.*)$")
	public CreateLeadPage enterCompanyName(String cname) {
		getDriver().findElement(By.id("createLeadForm_companyName")).sendKeys(cname);
		return this;
	}
	
	@Given ("Enter the first name (.*)$")
	public CreateLeadPage enterFirstName(String fname) {
		getDriver().findElement(By.id("createLeadForm_firstName")).sendKeys(fname);
		return this;
	}
	
	@Given ("Enter the last name (.*)$")	
	public CreateLeadPage enterLastName(String lname) {
		getDriver().findElement(By.id("createLeadForm_lastName")).sendKeys(lname);
		return this;
	}
	
	public CreateLeadPage enterPhoneNumber(String phno) {
		getDriver().findElement(By.id("createLeadForm_primaryPhoneNumber")).sendKeys(phno);
		return this;
	}
	
	@When ("Click on the create lead button")
	public ViewLeadPage clickCreateLeadButton() {
		getDriver().findElement(By.className("smallSubmit")).click();
		return new ViewLeadPage();
	}
	
	
	
	
}
