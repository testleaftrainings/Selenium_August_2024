package runner;

import org.testng.annotations.BeforeTest;

import base.ProjectSpecificMethod;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features = "src/main/java/features/Login.feature",
				 glue = {"base","pages"},
				 monochrome = true,
				 publish = true)
public class CucumberRunner2 extends ProjectSpecificMethod {

	@BeforeTest
	public void setTestDetails() {
		testcaseName ="Login";
		testcaseDesc ="CreateLead testcase with valid and invalid testData";
		author ="Gokul";
		category = "Regression";
	}
}
