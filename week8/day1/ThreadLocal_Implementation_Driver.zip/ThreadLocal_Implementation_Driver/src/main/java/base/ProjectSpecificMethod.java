package base;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import io.cucumber.testng.AbstractTestNGCucumberTests;

public class ProjectSpecificMethod extends AbstractTestNGCucumberTests{

//	public static RemoteWebDriver driver
	
	//private to secure the variable
	//static for single memory reference
	//final to restrict value changes
	
	private final static ThreadLocal<RemoteWebDriver> rd = new ThreadLocal<RemoteWebDriver>();
	public static Properties prop;
	public static ExtentReports extent;
	public static ExtentTest node;
	public static String testcaseName, testcaseDesc, author, category;
	
	public void setDriver() {
		ChromeDriver driver = new ChromeDriver();
		rd.set(driver);
	}
	
	public RemoteWebDriver getDriver() {
		return rd.get();
	}
	
	@Parameters("propertyFileName")
	@BeforeMethod
	public void preCondition(String propFileName) throws IOException {
		//Step 1: Instance the FileInputStream
		FileInputStream fis = new FileInputStream("./src/main/resources/"+propFileName+".properties");
		
		//Step 2: Create object for Properties
		prop = new Properties();
		
		//Step 3: Load the property file
		prop.load(fis);
				
//		driver = new ChromeDriver();
		setDriver();
		getDriver().get("http://leaftaps.com/opentaps/");
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		getDriver().manage().window().maximize();
	}
	
	@AfterMethod
	public void postCondition() {
		getDriver().close();
	}
	
	
	/*****Report*******/
	
	@BeforeSuite
	public void startReport() {
		// Set the report path
				ExtentHtmlReporter report = new ExtentHtmlReporter("./report/result.html");
				
				//To maintain history of the report
//				report.setAppendExisting(true);
				
				//Create an object for ExtentReports class
				extent = new ExtentReports();
				
				//Attach the report path to configure/create/generate report
				extent.attachReporter(report);
	}
	
	@BeforeClass
	public void createReport() {
		ExtentTest test = extent.createTest(testcaseName, testcaseDesc);
		node = test.createNode(testcaseName);
		node.assignAuthor(author);
		node.assignCategory(category);
		
	}
	
	@AfterSuite
	public void endReport() {
		extent.flush();
	}
	
	
}
