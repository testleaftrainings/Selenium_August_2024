package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.ProjectSpecificMethod;
import io.cucumber.java.en.When;

public class HomePage extends ProjectSpecificMethod {

	
	

	@When ("Click on leads tab")
	public LeadsPage clickLeadsTab() {
		getDriver().findElement(By.linkText(prop.getProperty("LeadsTab"))).click();
		return new LeadsPage();
	}
	
}
