package pages;

import org.openqa.selenium.By;

import base.ProjectSpecificMethod;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class WelcomePage extends ProjectSpecificMethod {

	
	
	@Then ("Verify the login is successfull")
	public void verifyLogin() {
		System.out.println(getDriver().getTitle());
	}
	
	@When ("Click on the crmsfa link")
	public HomePage clickCrmsfaLink() {
		getDriver().findElement(By.linkText("CRM/SFA")).click();
		return new HomePage();
	}
	
	public LoginPage clickLogoutButton() {
		
		return new LoginPage();
	}
	
}
