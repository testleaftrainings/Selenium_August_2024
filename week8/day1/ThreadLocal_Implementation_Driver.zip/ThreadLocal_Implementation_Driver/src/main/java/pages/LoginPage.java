package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.ProjectSpecificMethod;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class LoginPage extends ProjectSpecificMethod {

	
	

	@Given ("Enter the username")
	public LoginPage enterUsername() {
		
		System.out.println("Enter username "+ getDriver());
		
		try {
			getDriver().findElement(By.id("username")).sendKeys(prop.getProperty("username"));
			node.pass("username entered successfull");
		} catch (Exception e) {
			node.fail("unable to enter the username "+e);
		}
//		LoginPage lp = new LoginPage();
//		return lp;
		
//		return new LoginPage();
		
		return this;
	}
	
	@Given ("Enter the password")
	public LoginPage enterPassword() {
		try {
			getDriver().findElement(By.id("password")).sendKeys(prop.getProperty("password"));
			node.pass("password entered successfully");
		} catch (Exception e) {
			node.fail("unable to enter the password "+e);
		}
		return this;
	}
	
	@When ("Click on the login button")
	public WelcomePage clickLoginButton() {
		
		try {
			getDriver().findElement(By.className("decorativeSubmit")).click();
			node.pass("Login button clicked successfully");
		} catch (Exception e) {
			node.fail("unable to click the Login button "+e);
		}
		return new WelcomePage();
	}
	
	
}
