package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;

public class LoginPage extends ProjectSpecificMethod {

	
	public LoginPage(RemoteWebDriver driver) {
		this.driver= driver;
	}

	public LoginPage enterUsername() {
		
		System.out.println("Enter username "+ driver);
		
		driver.findElement(By.id("username")).sendKeys(prop.getProperty("username"));
//		LoginPage lp = new LoginPage();
//		return lp;
		
//		return new LoginPage();
		
		return this;
	}
	
	public LoginPage enterPassword() {
		driver.findElement(By.id("password")).sendKeys(prop.getProperty("password"));
		return this;
	}
	
	public WelcomePage clickLoginButton() {
		
		driver.findElement(By.className("decorativeSubmit")).click();
		return new WelcomePage(driver);
	}
	
	
}
