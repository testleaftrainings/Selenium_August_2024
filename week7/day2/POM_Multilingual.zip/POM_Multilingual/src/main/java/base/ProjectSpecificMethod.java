package base;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;

public class ProjectSpecificMethod {

	public RemoteWebDriver driver;
	public static Properties prop;
	
	@Parameters("propertyFileName")
	@BeforeMethod
	public void preCondition(String propFileName) throws IOException {
		//Step 1: Instance the FileInputStream
		FileInputStream fis = new FileInputStream("./src/main/resources/"+propFileName+".properties");
		
		//Step 2: Create object for Properties
		prop = new Properties();
		
		//Step 3: Load the property file
		prop.load(fis);
				
		driver = new ChromeDriver();
		driver.get("http://leaftaps.com/opentaps/");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.manage().window().maximize();
	}
	
	@AfterMethod
	public void postCondition() {
		driver.close();
	}
	
	
}
