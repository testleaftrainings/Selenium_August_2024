package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;

import base.ProjectSpecificMethod;
import io.cucumber.java.en.Then;

public class ViewLeadPage extends ProjectSpecificMethod {

	

	@Then ("Verify the lead is create successfull")
	public ViewLeadPage verifyLeadId() {
		String text = driver.findElement(By.id("viewLead_companyName_sp")).getText();
		String leadIDStr = text.replaceAll("[^0-9]", "");
		int leadID = Integer.parseInt(leadIDStr);
		Assert.assertTrue(leadID>0, "Lead id is verified");
		System.out.println(leadID);
		return this;
	}
	
}
