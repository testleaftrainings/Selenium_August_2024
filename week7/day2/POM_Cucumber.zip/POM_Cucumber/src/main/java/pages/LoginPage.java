package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.ProjectSpecificMethod;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class LoginPage extends ProjectSpecificMethod {

	
	

	@Given ("Enter the username")
	public LoginPage enterUsername() {
		
		System.out.println("Enter username "+ driver);
		
		driver.findElement(By.id("username")).sendKeys(prop.getProperty("username"));
//		LoginPage lp = new LoginPage();
//		return lp;
		
//		return new LoginPage();
		
		return this;
	}
	
	@Given ("Enter the password")
	public LoginPage enterPassword() {
		driver.findElement(By.id("password")).sendKeys(prop.getProperty("password"));
		return this;
	}
	
	@When ("Click on the login button")
	public WelcomePage clickLoginButton() {
		
		driver.findElement(By.className("decorativeSubmit")).click();
		return new WelcomePage();
	}
	
	
}
