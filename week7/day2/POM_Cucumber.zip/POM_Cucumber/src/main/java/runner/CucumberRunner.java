package runner;

import base.ProjectSpecificMethod;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features = "src/main/java/features",
				 glue = {"base","pages"},
				 monochrome = true,
				 publish = true,
				 tags ="@CreateLead")
public class CucumberRunner extends ProjectSpecificMethod {

}
