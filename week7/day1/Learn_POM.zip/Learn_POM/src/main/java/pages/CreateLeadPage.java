package pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import base.ProjectSpecificMethod;

public class CreateLeadPage extends ProjectSpecificMethod {

	
	public CreateLeadPage(RemoteWebDriver driver) {
		this.driver = driver;
	}

	public CreateLeadPage enterCompanyName() {
		
		return this;
	}
	
	public CreateLeadPage enterFirstName() {
		
		return this;
	}
	
	public CreateLeadPage enterLastName() {
		
		return this;
	}
	
	public CreateLeadPage enterPhoneNumber() {
		
		return this;
	}
	
	public ViewLeadPage clickCreateLeadButton() {
		
		return new ViewLeadPage(driver);
	}
	
	
	
	
}
